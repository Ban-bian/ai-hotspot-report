"""
社保业务前道客服系统 - 配置文件
"""
import os
from datetime import datetime
from pathlib import Path

# 项目根目录
BASE_DIR = Path(__file__).parent.parent

# 日志配置
LOG_DIR = BASE_DIR / "logs"
LOG_FILE = LOG_DIR / f"social_security_{datetime.now().strftime('%Y%m%d')}.log"

# 数据存储目录
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# 状态文件路径
STATE_FILE = DATA_DIR / "state.json"
CUSTOMER_ERROR_FILE = DATA_DIR / "customer_errors.json"

# 工单输出目录
WORKORDER_DIR = BASE_DIR / "output" / "workorders"
WORKORDER_DIR.mkdir(parents=True, exist_ok=True)

# 模板目录
TEMPLATE_DIR = BASE_DIR / "templates"
TEMPLATE_DIR.mkdir(exist_ok=True)

# 示例文件目录
EXAMPLE_DIR = BASE_DIR / "examples"

# 邮件配置
EMAIL_CONFIG = {
    "enabled": True,
    "smtp_server": "smtp.qq.com",
    "smtp_port": 587,
    "smtp_username": "48326583@qq.com",
    "smtp_password": "soqqngtrlkcbbggj",
    "imap_server": "imap.qq.com",
    "imap_port": 993,
    "inbox_folder": "INBOX",
    "attachment_download_dir": DATA_DIR / "attachments"
}

# 企业微信配置（Demo模式）
WEWORK_CONFIG = {
    "enabled": False,  # Demo模式默认关闭
    "corp_id": "",
    "agent_id": "",
    "secret": "",
    "token": "",
    "encoding_aes_key": ""
}

# 实操客服工单生成规则
WORKORDER_CONFIG = {
    "split_by_city": True,  # 按城市拆分工单
    "cities": ["北京", "上海", "广州", "深圳", "杭州", "成都", "武汉", "西安", "南京", "苏州"],
    "default_city": "其他城市"
}

# 错误处理配置
ERROR_CONFIG = {
    "max_error_attempts": 2,  # 最大错误次数，超过转人工
    "error_reset_days": 30,  # 错误计数重置天数
    "auto_escalate": True  # 自动升级到人工客服
}

# 增员工单必需字段
ADDITION_REQUIRED_FIELDS = [
    "客户派单日期", "客户名称", "人员分类", "身份证号", "姓名", "联系电话",
    "社保缴纳地", "实际工作地", "户口性质", "社保类别", "社保基数",
    "社保起缴年月", "公积金基数", "公积金比例", "起缴年月", "个人公积金账号"
]

# 减员工单必需字段
REDUCTION_REQUIRED_FIELDS = [
    "客户派单日期", "客户名称", "人员分类", "身份证号", "姓名", "联系电话",
    "福利缴纳地", "离职日期", "社保类别", "社保不产生月", "公积金不产生月", "停缴原因"
]

# 字段验证规则
VALIDATION_RULES = {
    "身份证号": {"pattern": r"^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$", "required": True},
    "联系电话": {"pattern": r"^1[3-9]\d{9}$", "required": True},
    "客户名称": {"min_length": 2, "required": True},
    "姓名": {"min_length": 2, "required": True},
    "人员分类": {"options": ["外包", "派遣", "代理"], "required": True},
    "户口性质": {"options": ["城镇", "农村"], "required": True},
    "社保类别": {"options": ["五险", "养老+医疗", "养老", "医疗", "住房公积金"], "required": True}
}

# 社保基数范围
SOCIAL_SECURITY_BASE = {
    "min": 5000,
    "max": 30000
}

# 日期格式
DATE_FORMATS = [
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%Y.%m.%d",
    "%Y%m%d"
]
