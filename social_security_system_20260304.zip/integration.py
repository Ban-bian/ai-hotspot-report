"""
整合流程模块 - 整合邮件和企业微信的处理流程
"""
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

from config.settings import EMAIL_CONFIG, WEWORK_CONFIG, WORKORDER_DIR
from modules.email_client import EmailClient
from modules.wework_client import WeWorkClient, get_city_operators
from modules.wework_message import WeWorkMessageParser, WeWorkMessage
from modules.parser import ExcelParser
from modules.validator import FieldValidator
from modules.workorder import WorkOrderGenerator
from modules.state_manager import StateManager
from models.schema import WorkOrderType

logger = logging.getLogger(__name__)


class SocialSecurityIntegration:
    """社保业务前道客服Agent - 整合版"""

    def __init__(self):
        """初始化Agent"""
        # 邮件客户端
        self.email_client = EmailClient(EMAIL_CONFIG)
        self.email_enabled = EMAIL_CONFIG.get("enabled", False)

        # 企业微信客户端
        self.wework_client = WeWorkClient(WEWORK_CONFIG)
        self.wework_enabled = WEWORK_CONFIG.get("enabled", False)

        # 消息解析器
        if self.wework_enabled:
            self.wework_parser = WeWorkMessageParser(
                token=WEWORK_CONFIG.get("token", ""),
                encoding_aes_key=WEWORK_CONFIG.get("encoding_aes_key", "")
            )
        else:
            self.wework_parser = None

        # 业务处理器
        self.parser = ExcelParser()
        self.validator = FieldValidator()
        self.workorder_generator = WorkOrderGenerator()
        self.state_manager = StateManager()

        logger.info("社保业务前道客服Agent初始化完成")
        logger.info(f"邮件模块: {'启用' if self.email_enabled else '禁用'}")
        logger.info(f"企业微信模块: {'启用' if self.wework_enabled else '禁用'}")

    def process_email_excel(self, excel_path: str) -> bool:
        """处理从邮件获取的Excel文件

        Args:
            excel_path: Excel文件路径

        Returns:
            处理成功返回True
        """
        logger.info(f"\n开始处理邮件附件Excel: {excel_path}")

        try:
            # 解析文件
            file_info = self.parser.get_file_info(excel_path)
            logger.info(f"文件信息: {file_info}")

            addition_records, reduction_records = self.parser.parse_file(excel_path)

            if addition_records:
                records = addition_records
                workorder_type = WorkOrderType.ADDITION
                customer_name = addition_records[0].customer_name if addition_records else "未知客户"
            elif reduction_records:
                records = reduction_records
                workorder_type = WorkOrderType.REDUCTION
                customer_name = reduction_records[0].customer_name if reduction_records else "未知客户"
            else:
                logger.warning("未解析到任何记录")
                return False

            logger.info(f"解析到 {len(records)} 条记录，类型: {workorder_type.value}")

            # 验证字段
            record_type = "addition" if workorder_type == WorkOrderType.ADDITION else "reduction"
            validation_result = self.validator.validate_batch(records, record_type)

            logger.info(f"验证结果: {validation_result['通过验证']}/{validation_result['总记录数']} 通过")

            # 生成工单
            workorders = self.workorder_generator.generate_workorder(
                records=records,
                workorder_type=workorder_type,
                source_file=Path(excel_path).name
            )

            # 保存工单
            workorder_files = self.workorder_generator.save_workorders(workorders)

            # 发送工单给实操客服
            if self.wework_enabled:
                self.send_workorders_to_operators(workorders, workorder_files, customer_name)

            return True

        except Exception as e:
            logger.error(f"处理邮件Excel失败: {e}")
            return False

    def process_wework_message(self, message: WeWorkMessage) -> bool:
        """处理企业微信消息

        Args:
            message: WeWorkMessage对象

        Returns:
            处理成功返回True
        """
        logger.info(f"\n处理企业微信消息: {message.msg_type} from {message.from_user}")

        try:
            # 检查是否为Excel文件
            if not self.wework_parser.is_excel_file(message):
                logger.warning("消息不包含Excel文件")
                return False

            # 下载Excel文件
            media_id = message.content.get("media_id", "")
            file_title = message.content.get("file_title", "未命名.xlsx")

            excel_path = self.download_wework_media(media_id, file_title)
            if not excel_path:
                logger.error("下载Excel文件失败")
                return False

            # 处理Excel文件
            success = self.process_email_excel(excel_path)

            # 回复客户
            if success:
                reply_content = "您的Excel文件已处理完成，工单已生成并发送给对应城市的实操客服同事。"
            else:
                reply_content = "抱歉，处理您的文件时遇到问题，请联系人工客服。"

            logger.info(f"回复客户: {reply_content}")

            return success

        except Exception as e:
            logger.error(f"处理企业微信消息失败: {e}")
            return False

    def download_wework_media(self, media_id: str, filename: str) -> Optional[str]:
        """下载企业微信媒体文件

        Args:
            media_id: 媒体ID
            filename: 文件名

        Returns:
            下载的文件路径，失败返回None
        """
        if not self.wework_enabled:
            logger.warning("企业微信模块未启用")
            return None

        try:
            access_token = self.wework_client.get_access_token()
            if not access_token:
                return None

            # 下载媒体文件
            import requests

            url = f"https://qyapi.weixin.qq.com/cgi-bin/media/get?access_token={access_token}&media_id={media_id}"
            response = requests.get(url, timeout=30)

            if response.status_code == 200:
                # 保存文件
                save_dir = WORKORDER_DIR / "received"
                save_dir.mkdir(parents=True, exist_ok=True)

                # 添加时间戳避免文件名冲突
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = save_dir / f"{timestamp}_{filename}"

                with open(save_path, 'wb') as f:
                    f.write(response.content)

                logger.info(f"成功下载企业微信文件: {save_path}")
                return str(save_path)
            else:
                logger.error(f"下载媒体文件失败: {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"下载媒体文件异常: {e}")
            return None

    def send_workorders_to_operators(self, workorders: List, workorder_files: List[str],
                                      customer_name: str) -> Dict[str, int]:
        """发送工单给实操客服

        Args:
            workorders: 工单对象列表
            workorder_files: 工单文件路径列表
            customer_name: 客户名称

        Returns:
            发送统计 {城市: 成功数量}
        """
        if not self.wework_enabled:
            logger.warning("企业微信模块未启用，跳过发送工单")
            return {}

        stats = {}

        for workorder, file_path in zip(workorders, workorder_files):
            city = workorder.city or "其他城市"
            operators = get_city_operators(city)

            if not operators:
                logger.warning(f"城市 {city} 未配置实操客服人员")
                continue

            success = self.wework_client.send_workorder_to_operator(
                file_path=file_path,
                operator_userids=operators,
                city=city,
                customer_name=customer_name
            )

            stats[city] = stats.get(city, 0) + (1 if success else 0)

        logger.info(f"工单发送统计: {stats}")
        return stats

    def poll_emails(self) -> int:
        """轮询并处理未读邮件

        Returns:
            处理的邮件数量
        """
        if not self.email_enabled:
            logger.warning("邮件模块未启用")
            return 0

        processed_count = 0

        try:
            # 连接邮件服务器
            if not self.email_client.connect():
                logger.error("无法连接邮件服务器")
                return 0

            # 获取未读邮件
            unread_emails = self.email_client.fetch_unread_emails()

            logger.info(f"找到 {len(unread_emails)} 封未读邮件")

            # 处理每封邮件
            for email_data in unread_emails:
                try:
                    # 提取Excel附件
                    excel_files = self.email_client.download_excel_attachments(email_data)

                    if not excel_files:
                        logger.warning(f"邮件无Excel附件: {email_data['subject']}")
                        self.email_client.mark_as_read(email_data['id'])
                        continue

                    logger.info(f"邮件包含 {len(excel_files)} 个Excel附件")

                    # 处理每个Excel文件
                    for excel_path in excel_files:
                        if self.process_email_excel(excel_path):
                            processed_count += 1

                    # 标记为已读
                    self.email_client.mark_as_read(email_data['id'])

                except Exception as e:
                    logger.error(f"处理邮件失败: {e}")

            # 断开连接
            self.email_client.disconnect()

        except Exception as e:
            logger.error(f"轮询邮件异常: {e}")

        return processed_count

    def run_integration(self):
        """运行整合流程（轮询模式）"""
        logger.info("=" * 60)
        logger.info("启动社保业务前道客服Agent（整合模式）")
        logger.info("=" * 60)

        import time

        while True:
            try:
                # 处理邮件
                email_count = self.poll_emails()

                # TODO: 处理企业微信消息（需要HTTP服务器接收回调）

                # 记录处理结果
                if email_count > 0:
                    logger.info(f"本轮处理完成: 处理了 {email_count} 封邮件")

                # 等待下次轮询
                time.sleep(60)  # 每分钟轮询一次

            except KeyboardInterrupt:
                logger.info("\n收到停止信号，退出程序")
                break
            except Exception as e:
                logger.error(f"运行异常: {e}")
                time.sleep(60)


def run_email_integration():
    """运行邮件集成模式"""
    integration = SocialSecurityIntegration()
    integration.poll_emails()


def run_wework_integration():
    """运行企业微信集成模式"""
    integration = SocialSecurityIntegration()
    # TODO: 启动HTTP服务器接收回调
    logger.info("企业微信集成模式需要HTTP服务器接收回调")
