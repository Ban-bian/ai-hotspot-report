# 社保业务前道客服Agent - 部署迁移指南

## 快速部署到其他电脑

### 方式一：Git版本控制（推荐）

1. **初始化Git仓库**
```bash
cd c:/Users/Administrator/CodeBuddy/20260304094928
git init
git add .
git commit -m "社保业务系统初始版本"
```

2. **推送到远程仓库**（GitHub/Gitee/GitLab）
```bash
git remote add origin <你的仓库地址>
git push -u origin main
```

3. **在其他电脑克隆**
```bash
git clone <你的仓库地址>
cd 20260304094928
```

4. **配置环境**
```bash
# 创建Python虚拟环境
python -m venv venv

# Windows激活
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 修改邮件配置
# 编辑 config/settings.py 中的 EMAIL_CONFIG
```

### 方式二：打包压缩迁移（简单快速）

1. **打包项目文件**
```bash
# 在当前目录下创建部署包
tar -czf social_security_system_$(date +%Y%m%d).tar.gz \
  --exclude='.git' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='venv' \
  --exclude='logs/*.log' \
  --exclude='output/workorders/*' \
  --exclude='data/attachments/*' \
  --exclude='-p' \
  .
```

2. **在Windows下压缩**（使用PowerShell或资源管理器）
   - 压缩以下内容（排除不必要的文件）：
     - `config/` 配置文件
     - `modules/` 核心代码模块
     - `models/` 数据模型
     - `templates/` 模板文件
     - `examples/` 示例文件
     - `main.py` 主程序
     - `requirements.txt` 依赖清单
     - `README.md` 说明文档
   - **排除**：
     - `__pycache__/` 缓存文件
     - `*.pyc` 字节码
     - `logs/` 日志文件（可选）
     - `output/workorders/` 已生成的工单（可选）
     - `data/attachments/` 下载的附件（可选）
     - `-p/` 临时目录

3. **在其他电脑部署**
```bash
# 解压项目文件
# 创建Python虚拟环境
python -m venv venv
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 修改配置（重要！）
# 编辑 config/settings.py，更新 EMAIL_CONFIG 中的邮件配置
```

## 配置检查清单

### 1. 依赖环境
- [ ] Python 3.8+
- [ ] 已安装依赖：`pip install -r requirements.txt`
- [ ] 创建虚拟环境（推荐）

### 2. 配置文件修改
- [ ] 修改 `config/settings.py` 中的邮件配置：
  ```python
  EMAIL_CONFIG = {
      "smtp_server": "smtp.qq.com",  # SMTP服务器
      "smtp_port": 587,              # SMTP端口
      "smtp_username": "你的邮箱",    # 邮箱地址
      "smtp_password": "授权码",     # 邮箱授权码
      "imap_server": "imap.qq.com",  # IMAP服务器
      "imap_port": 993,              # IMAP端口
  }
  ```

### 3. 目录结构
- [ ] `logs/` 日志目录自动创建
- [ ] `output/workorders/` 工单输出目录自动创建
- [ ] `data/attachments/` 邮件附件下载目录自动创建

### 4. 测试运行
```bash
python main.py
```

## 常见问题

### Q1: 邮件连接失败
- 检查QQ邮箱是否开启了IMAP/SMTP服务
- 确认使用的是授权码而非登录密码
- 检查网络连接

### Q2: Excel解析错误
- 确认Excel文件格式正确
- 检查表头位置（当前设置为第3行）
- 查看日志文件获取详细错误信息

### Q3: 依赖安装失败
- 使用国内镜像源：`pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple`
- 升级pip：`pip install --upgrade pip`

## 项目结构

```
20260304094928/
├── config/              # 配置文件
│   └── settings.py     # 主配置（需修改邮件配置）
├── modules/             # 核心模块
│   ├── email_client.py # 邮件客户端
│   ├── parser.py       # Excel解析器
│   ├── workorder.py    # 工单生成器
│   └── ...
├── models/              # 数据模型
├── templates/           # 工单模板
├── examples/            # 示例文件
├── data/               # 数据目录
│   └── attachments/    # 邮件附件下载
├── output/             # 输出目录
│   └── workorders/     # 生成的工单
├── logs/               # 日志文件
├── main.py             # 主程序入口
├── requirements.txt    # Python依赖
└── README.md           # 项目说明
```

## 当前功能特性

✅ QQ邮箱集成（IMAP接收邮件）
✅ Excel附件自动下载和解析
✅ 多级表头和合并单元格处理
✅ 增减员工单自动生成
✅ 按城市拆分工单
✅ 过滤示例数据
✅ 客户维度工单命名
✅ 字段验证和错误处理

## 联系方式

如需技术支持，请查看项目README.md或日志文件获取详细信息。
