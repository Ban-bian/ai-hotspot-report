"""
企业微信消息处理模块 - 解析接收到的消息
"""
import xml.etree.ElementTree as ET
from typing import Dict, Optional, Any
import logging
import base64
import hashlib
from pathlib import Path

logger = logging.getLogger(__name__)


class WeWorkMessage:
    """企业微信消息"""

    def __init__(self, msg_type: str, from_user: str, content: Any = None,
                 msg_id: str = "", create_time: int = 0, **kwargs):
        self.msg_type = msg_type
        self.from_user = from_user
        self.content = content
        self.msg_id = msg_id
        self.create_time = create_time
        self.extra = kwargs

    def __repr__(self):
        return f"<WeWorkMessage type={self.msg_type} from={self.from_user}>"


class WeWorkMessageParser:
    """企业微信消息解析器"""

    def __init__(self, token: str, encoding_aes_key: str):
        """初始化消息解析器

        Args:
            token: 回调Token
            encoding_aes_key: 回调EncodingAESKey
        """
        self.token = token
        self.encoding_aes_key = encoding_aes_key

    def verify_signature(self, signature: str, timestamp: str, nonce: str) -> bool:
        """验证消息签名

        Args:
            signature: 签名
            timestamp: 时间戳
            nonce: 随机数

        Returns:
            验证成功返回True
        """
        # 排序token、timestamp、nonce
        tmp_arr = [self.token, timestamp, nonce]
        tmp_arr.sort()

        # 拼接并SHA1加密
        tmp_str = ''.join(tmp_arr)
        sha1 = hashlib.sha1()
        sha1.update(tmp_str.encode('utf-8'))
        hashcode = sha1.hexdigest()

        return hashcode == signature

    def parse_message(self, xml_data: str) -> Optional[WeWorkMessage]:
        """解析XML格式的消息

        Args:
            xml_data: XML字符串

        Returns:
            WeWorkMessage对象
        """
        try:
            root = ET.fromstring(xml_data)

            # 提取基本信息
            msg_type = root.findtext("MsgType", "")
            from_user = root.findtext("FromUserName", "")
            to_user = root.findtext("ToUserName", "")
            msg_id = root.findtext("MsgId", "")
            create_time = int(root.findtext("CreateTime", 0) or 0)

            # 根据消息类型解析内容
            content = None

            if msg_type == "text":
                # 文本消息
                content = root.findtext("Content", "")

            elif msg_type == "image":
                # 图片消息
                content = {
                    "media_id": root.findtext("MediaId", ""),
                    "pic_url": root.findtext("PicUrl", "")
                }

            elif msg_type == "file":
                # 文件消息
                content = {
                    "media_id": root.findtext("MediaId", ""),
                    "file_title": root.findtext("FileTitle", ""),
                    "file_ext": root.findtext("FileExt", "")
                }

            elif msg_type == "voice":
                # 语音消息
                content = {
                    "media_id": root.findtext("MediaId", ""),
                    "format": root.findtext("Format", "")
                }

            elif msg_type == "video":
                # 视频消息
                content = {
                    "media_id": root.findtext("MediaId", ""),
                    "thumb_media_id": root.findtext("ThumbMediaId", "")
                }

            elif msg_type == "event":
                # 事件消息
                event_type = root.findtext("Event", "")
                content = {"event_type": event_type}

                # 处理特定事件
                if event_type == "subscribe":
                    content["event_key"] = root.findtext("EventKey", "")
                elif event_type == "click":
                    content["event_key"] = root.findtext("EventKey", "")

            message = WeWorkMessage(
                msg_type=msg_type,
                from_user=from_user,
                content=content,
                msg_id=msg_id,
                create_time=create_time,
                to_user=to_user
            )

            logger.info(f"接收到企业微信消息: {msg_type} from {from_user}")
            return message

        except Exception as e:
            logger.error(f"解析企业微信消息失败: {e}")
            return None

    def is_excel_file(self, message: WeWorkMessage) -> bool:
        """判断消息是否包含Excel文件

        Args:
            message: WeWorkMessage对象

        Returns:
            是Excel文件返回True
        """
        if message.msg_type == "file" and message.content:
            file_ext = message.content.get("file_ext", "").lower()
            return file_ext in ["xlsx", "xls"]

        # 检查文件名
        if message.msg_type == "file" and message.content:
            file_title = message.content.get("file_title", "").lower()
            return file_title.endswith((".xlsx", ".xls"))

        return False


def build_text_reply(to_user: str, from_user: str, content: str) -> str:
    """构建文本回复消息

    Args:
        to_user: 接收用户ID
        from_user: 发送用户ID
        content: 回复内容

    Returns:
        XML格式字符串
    """
    xml = f"""
    <xml>
        <ToUserName><![CDATA[{to_user}]]></ToUserName>
        <FromUserName><![CDATA[{from_user}]]></FromUserName>
        <CreateTime>{int(Path.cwd().stat().st_mtime)}</CreateTime>
        <MsgType><![CDATA[text]]></MsgType>
        <Content><![CDATA[{content}]]></Content>
    </xml>
    """
    return xml.strip()


def build_file_reply(to_user: str, from_user: str, media_id: str) -> str:
    """构建文件回复消息

    Args:
        to_user: 接收用户ID
        from_user: 发送用户ID
        media_id: 文件媒体ID

    Returns:
        XML格式字符串
    """
    xml = f"""
    <xml>
        <ToUserName><![CDATA[{to_user}]]></ToUserName>
        <FromUserName><![CDATA[{from_user}]]></FromUserName>
        <CreateTime>{int(Path.cwd().stat().st_mtime)}</CreateTime>
        <MsgType><![CDATA[file]]></MsgType>
        <File>
            <MediaId><![CDATA[{media_id}]]></MediaId>
        </File>
    </xml>
    """
    return xml.strip()


def build_workorder_reply(to_user: str, from_user: str, workorder_info: Dict) -> str:
    """构建工单处理回复

    Args:
        to_user: 接收用户ID
        from_user: 发送用户ID
        workorder_info: 工单信息

    Returns:
        XML格式字符串
    """
    content = f"""工单处理完成

客户: {workorder_info.get('customer', '未知')}
工单类型: {workorder_info.get('type', '未知')}
记录数: {workorder_info.get('count', 0)}

工单已发送给对应城市的实操客服同事处理。"""

    return build_text_reply(to_user, from_user, content)
