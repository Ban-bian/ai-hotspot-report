"""
表格解析模块
用于解析Excel格式的社保增减员工单
"""
import pandas as pd
from typing import List, Dict, Tuple
from pathlib import Path
import logging
from datetime import datetime

from config.settings import ADDITION_REQUIRED_FIELDS, REDUCTION_REQUIRED_FIELDS, DATA_DIR
from models.schema import AdditionRecord, ReductionRecord, WorkOrderType

logger = logging.getLogger(__name__)


class ExcelParser:
    """Excel表格解析器"""

    def __init__(self):
        self.supported_formats = [".xlsx", ".xls"]

    def parse_file(self, file_path: str) -> Tuple[List[AdditionRecord], List[ReductionRecord]]:
        """
        解析Excel文件
        返回：(增员记录列表, 减员记录列表)
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        if file_path.suffix not in self.supported_formats:
            raise ValueError(f"不支持的文件格式: {file_path.suffix}，仅支持 {self.supported_formats}")

        try:
            # 尝试不同的表头位置读取
            df = self._read_excel_with_header_detection(file_path)

            if df is None:
                raise ValueError("无法识别Excel文件格式")

            # 清理列名（去除空格）
            df.columns = df.columns.str.strip()

            logger.info(f"成功读取文件: {file_path}，共 {len(df)} 行数据")

            # 判断工单类型（通过列名判断）
            if self._is_addition_order(df.columns.tolist()):
                logger.info("识别为增员工单")
                addition_records = self._parse_addition_records(df)
                return addition_records, []
            elif self._is_reduction_order(df.columns.tolist()):
                logger.info("识别为减员工单")
                reduction_records = self._parse_reduction_records(df)
                return [], reduction_records
            else:
                raise ValueError("无法识别工单类型，请检查表格列名是否正确")

        except Exception as e:
            logger.error(f"解析Excel文件失败: {e}")
            raise

    def _read_excel_with_header_detection(self, file_path: Path) -> pd.DataFrame:
        """自动检测表头位置并读取Excel"""
        # 尝试从不同位置读取表头
        header_candidates = [2, 3, 1, 0]  # 优先尝试第3行

        for header_row in header_candidates:
            try:
                df = pd.read_excel(file_path, header=header_row, engine='openpyxl')

                # 清理列名，去除NaN和Unnamed
                columns = []
                for col in df.columns:
                    col_str = str(col).strip() if pd.notna(col) else ""
                    if col_str == "Unnamed" or "Unnamed:" in col_str:
                        col_str = ""
                    columns.append(col_str)

                df.columns = columns

                # 检查是否包含关键字段
                if self._is_addition_order(columns) or self._is_reduction_order(columns):
                    logger.info(f"找到有效表头，位于第 {header_row + 1} 行")
                    return df

            except Exception as e:
                logger.debug(f"尝试表头位置 {header_row} 失败: {e}")
                continue

        # 如果都没有找到，尝试原始方式
        try:
            df = pd.read_excel(file_path, engine='openpyxl')
            df.columns = df.columns.str.strip()
            return df
        except:
            return None

    def _is_addition_order(self, columns: List[str]) -> bool:
        """判断是否为增员工单"""
        # 增员特有字段（支持多种字段名）
        addition_keywords = ["福利缴纳地", "社保缴纳地", "实际工作地", "员工姓名", "证件号码"]
        return any(kw in columns for kw in addition_keywords)

    def _is_reduction_order(self, columns: List[str]) -> bool:
        """判断是否为减员工单"""
        # 减员特有字段
        return "离职日期" in columns or "停缴原因" in columns

    def _parse_addition_records(self, df: pd.DataFrame) -> List[AdditionRecord]:
        """解析增员记录"""
        records = []

        # 字段映射：支持多种字段名
        field_mapping = {
            "customer_order_date": ["客户派单日期", "派单日期"],
            "customer_name": ["客户名称"],
            "person_category": ["人员分类"],
            "id_card": ["身份证号", "证件号码"],
            "name": ["员工姓名", "姓名"],
            "phone": ["联系电话", "员工联系电话"],
            "social_security_location": ["福利缴纳地", "社保缴纳地"],
            "work_location": ["实际工作地"],
            "household_type": ["户口性质", "户口\n性质"],
            "social_security_type": ["社会保险类别", "社保类别"],
            "social_security_base": ["申报基数", "社保基数", "社会保险"],
            "social_security_start_month": ["起缴年月"],
            "housing_fund_base": ["申报基数", "公积金基数", "公积金"],
            "housing_fund_rate": ["比例", "公积金比例"],
            "housing_fund_start_month": ["起缴年月"],
            "personal_housing_fund_account": ["个人公积金账号"]
        }

        # 特殊处理：处理重复列名（公积金、申报基数等）
        # 使用列索引来正确获取多级表头的数据

        for idx, row in df.iterrows():
            try:
                # 辅助函数：获取字段值
                def get_field(field_name: str) -> str:
                    candidates = field_mapping.get(field_name, [])
                    for candidate in candidates:
                        # 如果列名存在
                        if candidate in row.index and pd.notna(row[candidate]):
                            return str(row[candidate]).strip()
                    return ""

                def get_float_field(field_name: str) -> float:
                    val = get_field(field_name)
                    try:
                        return float(val) if val else 0
                    except:
                        return 0

                # 特殊处理：按索引获取社保和公积金相关字段
                # 根据之前看到的列名：
                # 列23: "社会保险" (基数), 列24: "起缴年月"
                # 列25: "个人公积金账号", 列26: "申报基数"(公积金), 列27: "比例", 列28: "起缴年月"

                # 使用列索引获取更准确的值
                def get_by_index(col_idx: int) -> str:
                    if col_idx < len(row):
                        val = row.iloc[col_idx]
                        return str(val).strip() if pd.notna(val) else ""
                    return ""

                record = AdditionRecord(
                    customer_order_date=get_field("customer_order_date") or get_by_index(1),
                    customer_name=get_field("customer_name") or get_by_index(2),
                    person_category=get_field("person_category") or get_by_index(3),
                    id_card=get_field("id_card") or get_by_index(4),
                    name=get_field("name") or get_by_index(7),  # 员工姓名在索引7
                    phone=get_field("phone") or get_by_index(9),  # 员工联系电话在索引9
                    social_security_location=get_field("social_security_location") or get_by_index(21),  # 福利缴纳地在索引21
                    work_location=get_field("work_location") or get_by_index(22),  # 实际工作地在索引22
                    household_type=get_field("household_type").replace("\n", "") or get_by_index(27),  # 户口性质在索引27
                    social_security_type=get_field("social_security_type") or get_by_index(28),  # 社会保险类别在索引28
                    social_security_base=get_float_field("social_security_base") or self._safe_float(get_by_index(29)),  # 社会保险(基数)在索引29
                    social_security_start_month=get_field("social_security_start_month") or get_by_index(30),  # 起缴年月在索引30
                    housing_fund_base=get_float_field("housing_fund_base") or self._safe_float(get_by_index(32)),  # 公积金(基数)在索引32
                    housing_fund_rate=get_float_field("housing_fund_rate") or self._safe_rate(get_by_index(33)),  # 比例在索引33
                    housing_fund_start_month=get_field("housing_fund_start_month") or get_by_index(34),  # 起缴年月在索引34
                    personal_housing_fund_account=get_field("personal_housing_fund_account") or get_by_index(31),  # 公积金账号在索引31
                    row_index=idx + 2  # Excel行号（从1开始，减去标题行）
                )
                # 只添加有效记录：必须至少有姓名，且不能是说明文本
                # 检查是否为示例或说明行（第一列标记为"例"的行）
                first_col_value = str(row.iloc[0]) if len(row) > 0 else ""
                valid_keywords = ["必填", "填写说明", "格式", "举例", "**", "例"]
                is_instruction = (
                    any(kw in record.name for kw in valid_keywords) or
                    any(kw in record.customer_name for kw in valid_keywords) or
                    first_col_value.strip() == "例" or
                    "XXXXXX" in record.customer_name
                )
                if record.name and not is_instruction and len(record.name) < 50:
                    records.append(record)
            except Exception as e:
                logger.warning(f"解析第 {idx + 2} 行数据失败: {e}")
                # 跳过错误行，继续处理
                continue

        logger.info(f"成功解析 {len(records)} 条增员记录")
        return records

    def _safe_float(self, val: str) -> float:
        """安全转换为float"""
        try:
            return float(val) if val else 0
        except:
            return 0

    def _safe_rate(self, val: str) -> float:
        """安全转换比例为float（支持 "5+5" 格式）"""
        try:
            if not val:
                return 0
            if "+" in val:
                # 格式如 "5+5"，取第一个数字作为比例
                parts = val.split("+")
                return float(parts[0]) if parts[0] else 0
            return float(val)
        except:
            return 0

    def _parse_reduction_records(self, df: pd.DataFrame) -> List[ReductionRecord]:
        """解析减员记录"""
        records = []

        for idx, row in df.iterrows():
            try:
                record = ReductionRecord(
                    customer_order_date=str(row.get("客户派单日期", "")).strip(),
                    customer_name=str(row.get("客户名称", "")).strip(),
                    person_category=str(row.get("人员分类", "")).strip(),
                    id_card=str(row.get("身份证号", "")).strip(),
                    name=str(row.get("姓名", "")).strip(),
                    phone=str(row.get("联系电话", "")).strip(),
                    benefit_location=str(row.get("福利缴纳地", "")).strip(),
                    resignation_date=str(row.get("离职日期", "")).strip(),
                    social_security_type=str(row.get("社保类别", "")).strip(),
                    social_security_non_production_month=str(row.get("社保不产生月", "")).strip(),
                    housing_fund_non_production_month=str(row.get("公积金不产生月", "")).strip(),
                    stop_reason=str(row.get("停缴原因", "")).strip(),
                    row_index=idx + 2  # Excel行号
                )
                records.append(record)
            except Exception as e:
                logger.warning(f"解析第 {idx + 2} 行数据失败: {e}")
                continue

        logger.info(f"成功解析 {len(records)} 条减员记录")
        return records

    def get_file_info(self, file_path: str) -> Dict:
        """获取文件基本信息"""
        file_path = Path(file_path)
        df = pd.read_excel(file_path, engine='openpyxl')

        columns = df.columns.tolist()
        columns = [col.strip() for col in columns]

        # 判断工单类型
        if self._is_addition_order(columns):
            workorder_type = WorkOrderType.ADDITION
        elif self._is_reduction_order(columns):
            workorder_type = WorkOrderType.REDUCTION
        else:
            workorder_type = "未知"

        return {
            "文件名": file_path.name,
            "文件大小": f"{file_path.stat().st_size / 1024:.2f} KB",
            "总行数": len(df),
            "列名": columns,
            "工单类型": workorder_type
        }
