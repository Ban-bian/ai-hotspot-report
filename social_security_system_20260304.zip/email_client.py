"""
邮件客户端模块 - IMAP协议读取邮件和Excel附件
"""
import imaplib
import email
from email.header import decode_header
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import logging
import re
from datetime import datetime

from config.settings import EMAIL_CONFIG, DATA_DIR

logger = logging.getLogger(__name__)


class EmailClient:
    """IMAP邮件客户端"""

    def __init__(self, config: Optional[Dict] = None):
        """初始化邮件客户端

        Args:
            config: 邮件配置字典，默认使用EMAIL_CONFIG
        """
        self.config = config or EMAIL_CONFIG
        self.imap_server = None
        self.attachment_dir = Path(self.config.get("attachment_download_dir", DATA_DIR / "attachments"))
        self.attachment_dir.mkdir(parents=True, exist_ok=True)

    def connect(self) -> bool:
        """连接IMAP服务器

        Returns:
            连接成功返回True，否则返回False
        """
        try:
            # 连接IMAP服务器
            self.imap_server = imaplib.IMAP4_SSL(
                self.config["imap_server"],
                self.config.get("imap_port", 993)
            )

            # 登录
            self.imap_server.login(
                self.config["smtp_username"],
                self.config["smtp_password"]
            )

            # 选择收件箱
            self.imap_server.select(self.config.get("inbox_folder", "INBOX"))

            logger.info(f"成功连接到邮件服务器: {self.config['imap_server']}")
            return True

        except Exception as e:
            logger.error(f"邮件服务器连接失败: {e}")
            return False

    def fetch_unread_emails(self) -> List[Dict]:
        """获取未读邮件

        Returns:
            未读邮件列表，每封邮件包含：id, subject, sender, date, body, attachments
        """
        if not self.imap_server:
            logger.error("未连接到邮件服务器，请先调用connect()")
            return []

        try:
            # 搜索未读邮件
            status, messages = self.imap_server.search(None, '(UNSEEN)')

            if status != 'OK':
                logger.warning("未找到未读邮件")
                return []

            email_ids = messages[0].split()
            logger.info(f"找到 {len(email_ids)} 封未读邮件")

            emails = []
            for email_id in email_ids:
                email_data = self._fetch_email_by_id(email_id)
                if email_data:
                    emails.append(email_data)

            return emails

        except Exception as e:
            logger.error(f"获取未读邮件失败: {e}")
            return []

    def _fetch_email_by_id(self, email_id: bytes) -> Optional[Dict]:
        """根据ID获取邮件详情

        Args:
            email_id: 邮件ID

        Returns:
            邮件详情字典
        """
        try:
            # 获取邮件内容
            status, msg_data = self.imap_server.fetch(email_id, '(RFC822)')

            if status != 'OK':
                return None

            # 解析邮件
            raw_email = msg_data[0][1]
            email_message = email.message_from_bytes(raw_email)

            # 解析邮件头
            subject = self._decode_header(email_message.get("Subject", ""))
            sender = self._decode_header(email_message.get("From", ""))
            date_str = email_message.get("Date", "")

            # 解析正文和附件
            body, attachments = self._parse_email_body(email_message)

            email_info = {
                "id": email_id.decode(),
                "subject": subject,
                "sender": sender,
                "date": date_str,
                "body": body,
                "attachments": attachments,
                "raw_message": email_message
            }

            return email_info

        except Exception as e:
            logger.error(f"解析邮件失败 (ID: {email_id}): {e}")
            return None

    def _parse_email_body(self, email_message) -> Tuple[str, List[Dict]]:
        """解析邮件正文和附件

        Args:
            email_message: email.message对象

        Returns:
            (正文文本, 附件列表)
        """
        body_text = ""
        attachments = []

        for part in email_message.walk():
            content_type = part.get_content_type()
            content_disposition = part.get("Content-Disposition", "")

            # 获取正文
            if content_type == "text/plain" and "attachment" not in content_disposition:
                payload = part.get_payload(decode=True)
                if payload:
                    try:
                        charset = part.get_content_charset() or 'utf-8'
                        body_text = payload.decode(charset)
                    except:
                        body_text = str(payload)

            # 获取附件
            elif "attachment" in content_disposition:
                filename = part.get_filename()
                if filename:
                    filename = self._decode_header(filename)
                    payload = part.get_payload(decode=True)

                    # 保存附件
                    save_path = self.attachment_dir / filename
                    with open(save_path, 'wb') as f:
                        f.write(payload)

                    # 检查是否为Excel文件
                    is_excel = filename.lower().endswith(('.xlsx', '.xls'))

                    attachments.append({
                        "filename": filename,
                        "filepath": str(save_path),
                        "size": len(payload),
                        "is_excel": is_excel
                    })

                    if is_excel:
                        logger.info(f"下载Excel附件: {filename}")

        return body_text, attachments

    def _decode_header(self, header: str) -> str:
        """解码邮件头

        Args:
            header: 邮件头字符串

        Returns:
            解码后的字符串
        """
        if not header:
            return ""

        decoded_parts = []
        for content, encoding in decode_header(header):
            if isinstance(content, bytes):
                try:
                    decoded_parts.append(content.decode(encoding or 'utf-8'))
                except:
                    decoded_parts.append(content.decode('utf-8', errors='ignore'))
            else:
                decoded_parts.append(str(content))

        return ''.join(decoded_parts)

    def download_excel_attachments(self, email_data: Dict) -> List[str]:
        """下载邮件中的Excel附件（附件已在解析时保存）

        Args:
            email_data: 邮件数据

        Returns:
            Excel附件文件路径列表
        """
        excel_files = [
            att["filepath"]
            for att in email_data.get("attachments", [])
            if att["is_excel"]
        ]
        return excel_files

    def mark_as_read(self, email_id: str) -> bool:
        """标记邮件为已读

        Args:
            email_id: 邮件ID

        Returns:
            成功返回True
        """
        try:
            self.imap_server.store(email_id, '+FLAGS', '\\Seen')
            logger.debug(f"标记邮件 {email_id} 为已读")
            return True
        except Exception as e:
            logger.error(f"标记邮件失败: {e}")
            return False

    def disconnect(self):
        """断开连接"""
        if self.imap_server:
            try:
                self.imap_server.close()
                self.imap_server.logout()
                logger.info("已断开邮件服务器连接")
            except Exception as e:
                logger.error(f"断开连接失败: {e}")

    def __enter__(self):
        """上下文管理器入口"""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()


def test_email_connection(config: Dict) -> bool:
    """测试邮件连接

    Args:
        config: 邮件配置

    Returns:
        连接成功返回True
    """
    try:
        with EmailClient(config) as client:
            return client.imap_server is not None
    except Exception as e:
        logger.error(f"邮件连接测试失败: {e}")
        return False
