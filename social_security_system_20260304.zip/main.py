"""
社保业务前道客服系统 - 主程序入口
"""
import sys
import logging
from pathlib import Path
from datetime import datetime

from config.settings import LOG_DIR, LOG_FILE, EXAMPLE_DIR
from modules.parser import ExcelParser
from modules.validator import FieldValidator
from modules.workorder import WorkOrderGenerator
from modules.state_manager import StateManager
from modules.integration import SocialSecurityIntegration, run_email_integration
from models.schema import WorkOrderType

# 配置日志
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


class SocialSecurityAgent:
    """社保业务前道客服Agent"""

    def __init__(self):
        self.parser = ExcelParser()
        self.validator = FieldValidator()
        self.workorder_generator = WorkOrderGenerator()
        self.state_manager = StateManager()

        logger.info("=" * 60)
        logger.info("社保业务前道客服系统启动")
        logger.info("=" * 60)

    def process_file(self, file_path: str):
        """
        处理Excel文件
        完整流程：解析 -> 验证 -> 生成工单 -> 保存
        """
        logger.info(f"\n开始处理文件: {file_path}")
        logger.info("-" * 60)

        # 步骤1: 解析文件
        logger.info("步骤1: 解析Excel文件")
        try:
            file_info = self.parser.get_file_info(file_path)
            logger.info(f"文件信息: {file_info}")

            addition_records, reduction_records = self.parser.parse_file(file_path)

            if addition_records:
                logger.info(f"解析到 {len(addition_records)} 条增员记录")
                records = addition_records
                workorder_type = WorkOrderType.ADDITION
                customer_name = addition_records[0].customer_name if addition_records else "未知客户"
            elif reduction_records:
                logger.info(f"解析到 {len(reduction_records)} 条减员记录")
                records = reduction_records
                workorder_type = WorkOrderType.REDUCTION
                customer_name = reduction_records[0].customer_name if reduction_records else "未知客户"
            else:
                logger.warning("未解析到任何记录")
                return

        except Exception as e:
            logger.error(f"文件解析失败: {e}")
            return

        # 步骤2: 字段验证
        logger.info("\n步骤2: 字段验证")
        record_type = "addition" if workorder_type == WorkOrderType.ADDITION else "reduction"
        validation_result = self.validator.validate_batch(records, record_type)

        logger.info(f"验证结果: {validation_result['通过验证']}/{validation_result['总记录数']} 通过")
        logger.info(f"验证失败: {validation_result['验证失败']} 条")

        if validation_result['验证失败'] > 0:
            logger.warning("\n验证错误详情:")
            for error in validation_result['错误详情'][:10]:  # 只显示前10条
                logger.warning(f"  - {error}")

            # 记录客户错误
            error_summary = f"字段验证失败，共 {validation_result['验证失败']} 条记录有误"
            error_record = self.state_manager.record_error(customer_name, error_summary)

            # 检查是否需要转人工
            if error_record.escalate_to_manual:
                logger.warning(f"\n⚠️  客户 {customer_name} 错误次数已达上限，需要转人工客服处理！")
            else:
                logger.info(f"\n提示: 客户 {customer_name} 当前错误次数: {error_record.error_count}/{self.state_manager.max_error_attempts}")

        # 步骤3: 生成工单
        logger.info("\n步骤3: 生成工单")
        try:
            workorders = self.workorder_generator.generate_workorder(
                records=records,
                workorder_type=workorder_type,
                source_file=Path(file_path).name
            )

            # 步骤4: 保存工单
            logger.info("\n步骤4: 保存工单")
            filepaths = self.workorder_generator.save_workorders(workorders)

            # 生成汇总信息
            summary = self.workorder_generator.generate_summary(workorders)
            logger.info(f"\n工单汇总:")
            logger.info(f"  - 工单总数: {summary['工单总数']}")
            logger.info(f"  - 总记录数: {summary['总记录数']}")
            logger.info(f"  - 错误记录数: {summary['错误记录数']}")
            logger.info(f"  - 城市分布: {summary['城市分布']}")

            logger.info(f"\n工单文件已保存到:")
            for filepath in filepaths:
                logger.info(f"  - {filepath}")

        except Exception as e:
            logger.error(f"工单生成失败: {e}")
            return

        logger.info("\n" + "=" * 60)
        logger.info("文件处理完成")
        logger.info("=" * 60)

    def run_demo(self):
        """运行Demo示例"""
        logger.info("\n" + "=" * 60)
        logger.info("运行Demo模式")
        logger.info("=" * 60)

        # 查找示例文件
        example_files = list(EXAMPLE_DIR.glob("*.xlsx")) + list(EXAMPLE_DIR.glob("*.xls"))

        if not example_files:
            logger.warning("未找到示例Excel文件")
            logger.info(f"请在 {EXAMPLE_DIR} 目录下放置示例文件")
            return

        # 处理每个示例文件
        for file_path in example_files:
            logger.info(f"\n\n处理示例文件: {file_path.name}")
            self.process_file(str(file_path))


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description="社保业务前道客服系统")
    parser.add_argument('--file', '-f', type=str, help='要处理的Excel文件路径')
    parser.add_argument('--demo', '-d', action='store_true', help='运行Demo模式')
    parser.add_argument('--email', '-e', action='store_true', help='运行邮件集成模式')
    parser.add_argument('--integration', '-i', action='store_true', help='运行完整整合模式')

    args = parser.parse_args()

    agent = SocialSecurityAgent()

    if args.integration:
        # 整合模式：邮件 + 企业微信
        integration = SocialSecurityIntegration()
        integration.run_integration()
    elif args.email:
        # 邮件集成模式
        run_email_integration()
    elif args.demo:
        # Demo模式
        agent.run_demo()
    elif args.file:
        # 处理单个文件
        agent.process_file(args.file)
    else:
        print("社保业务前道客服系统")
        print("\n使用方法:")
        print("  python main.py --file <Excel文件路径>    # 处理指定文件")
        print("  python main.py --demo                   # 运行Demo模式")
        print("  python main.py --email                  # 运行邮件集成模式")
        print("  python main.py --integration            # 运行完整整合模式")
        print("\n示例:")
        print("  python main.py -f examples/addition_example.xlsx")
        print("  python main.py -d")
        print("  python main.py -e")
        print("  python main.py -i")


if __name__ == "__main__":
    main()
