"""
状态管理模块
用于管理客户错误记录、工单状态等
"""
import json
from typing import Dict, List, Optional
from pathlib import Path
from datetime import datetime, timedelta
import logging

from config.settings import STATE_FILE, CUSTOMER_ERROR_FILE, ERROR_CONFIG, DATA_DIR
from models.schema import CustomerErrorRecord

logger = logging.getLogger(__name__)


class StateManager:
    """状态管理器"""

    def __init__(self):
        self.state_file = STATE_FILE
        self.customer_error_file = CUSTOMER_ERROR_FILE
        self.max_error_attempts = ERROR_CONFIG["max_error_attempts"]
        self.error_reset_days = ERROR_CONFIG["error_reset_days"]

        # 确保数据目录存在
        DATA_DIR.mkdir(exist_ok=True)

        # 初始化状态
        self.customer_errors: Dict[str, CustomerErrorRecord] = {}
        self._load_customer_errors()

    def _load_customer_errors(self):
        """加载客户错误记录"""
        if not self.customer_error_file.exists():
            logger.info("客户错误记录文件不存在，创建新文件")
            self._save_customer_errors()
            return

        try:
            with open(self.customer_error_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # 转换为CustomerErrorRecord对象
            for customer_name, record_data in data.items():
                # 映射中文键到英文参数
                self.customer_errors[customer_name] = CustomerErrorRecord(
                    customer_name=record_data.get("客户名称", customer_name),
                    error_count=record_data.get("错误次数", 0),
                    last_error_date=record_data.get("最后错误日期", ""),
                    last_error_reason=record_data.get("最后错误原因", ""),
                    escalate_to_manual=record_data.get("已转人工", False)
                )

            logger.info(f"成功加载 {len(self.customer_errors)} 条客户错误记录")
        except Exception as e:
            logger.error(f"加载客户错误记录失败: {e}")
            self.customer_errors = {}

    def _save_customer_errors(self):
        """保存客户错误记录"""
        try:
            data = {
                name: record.to_dict()
                for name, record in self.customer_errors.items()
            }

            with open(self.customer_error_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            logger.debug(f"客户错误记录已保存，共 {len(self.customer_errors)} 条")
        except Exception as e:
            logger.error(f"保存客户错误记录失败: {e}")

    def record_error(
        self,
        customer_name: str,
        error_reason: str
    ) -> CustomerErrorRecord:
        """
        记录客户错误
        返回：更新后的错误记录
        """
        customer_name = customer_name.strip()
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 检查是否需要重置错误计数
        if customer_name in self.customer_errors:
            last_error_date_str = self.customer_errors[customer_name].last_error_date
            try:
                last_error_date = datetime.strptime(last_error_date_str, "%Y-%m-%d %H:%M:%S")
                days_passed = (datetime.now() - last_error_date).days

                if days_passed >= self.error_reset_days:
                    # 重置错误计数
                    logger.info(f"客户 {customer_name} 错误计数已重置（{days_passed}天无错误）")
                    self.customer_errors[customer_name] = CustomerErrorRecord(
                        customer_name=customer_name,
                        error_count=1,
                        last_error_date=current_time,
                        last_error_reason=error_reason,
                        escalate_to_manual=False
                    )
                else:
                    # 增加错误计数
                    record = self.customer_errors[customer_name]
                    record.error_count += 1
                    record.last_error_date = current_time
                    record.last_error_reason = error_reason

                    # 检查是否需要转人工
                    if record.error_count >= self.max_error_attempts:
                        record.escalate_to_manual = True
                        logger.warning(f"客户 {customer_name} 错误次数已达 {self.max_error_attempts}，转人工客服")
            except Exception as e:
                logger.warning(f"解析错误日期失败: {e}")
                self.customer_errors[customer_name] = CustomerErrorRecord(
                    customer_name=customer_name,
                    error_count=1,
                    last_error_date=current_time,
                    last_error_reason=error_reason,
                    escalate_to_manual=False
                )
        else:
            # 新客户错误记录
            self.customer_errors[customer_name] = CustomerErrorRecord(
                customer_name=customer_name,
                error_count=1,
                last_error_date=current_time,
                last_error_reason=error_reason,
                escalate_to_manual=False
            )
            logger.info(f"创建客户 {customer_name} 的错误记录")

        # 保存
        self._save_customer_errors()

        return self.customer_errors[customer_name]

    def get_customer_error(self, customer_name: str) -> Optional[CustomerErrorRecord]:
        """获取客户错误记录"""
        return self.customer_errors.get(customer_name.strip())

    def should_escalate(self, customer_name: str) -> bool:
        """判断是否需要转人工客服"""
        record = self.get_customer_error(customer_name)
        if record:
            return record.escalate_to_manual
        return False

    def reset_customer_errors(self, customer_name: str):
        """重置客户错误计数"""
        customer_name = customer_name.strip()

        if customer_name in self.customer_errors:
            self.customer_errors[customer_name].error_count = 0
            self.customer_errors[customer_name].escalate_to_manual = False
            self._save_customer_errors()
            logger.info(f"客户 {customer_name} 错误计数已重置")

    def get_all_customers_with_errors(self) -> List[CustomerErrorRecord]:
        """获取所有有错误记录的客户"""
        return list(self.customer_errors.values())

    def get_escalated_customers(self) -> List[CustomerErrorRecord]:
        """获取已转人工的客户列表"""
        return [r for r in self.customer_errors.values() if r.escalate_to_manual]

    def generate_error_report(self) -> Dict:
        """生成错误报告"""
        records = list(self.customer_errors.values())

        return {
            "总客户数": len(records),
            "有错误客户数": len(records),
            "已转人工客户数": len([r for r in records if r.escalate_to_manual]),
            "平均错误次数": sum(r.error_count for r in records) / len(records) if records else 0,
            "报告生成时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "错误详情": [r.to_dict() for r in records]
        }
