"""
工单生成模块
用于生成实操客服工单（按城市拆分）
"""
import json
import uuid
from typing import List, Dict
from pathlib import Path
import logging
from datetime import datetime
import pandas as pd

from config.settings import WORKORDER_CONFIG, WORKORDER_DIR
from models.schema import WorkOrder, AdditionRecord, ReductionRecord, WorkOrderType

logger = logging.getLogger(__name__)


class WorkOrderGenerator:
    """工单生成器"""

    def __init__(self):
        self.split_by_city = WORKORDER_CONFIG["split_by_city"]
        self.cities = WORKORDER_CONFIG["cities"]
        self.default_city = WORKORDER_CONFIG["default_city"]

    def generate_workorder(
        self,
        records: List,
        workorder_type: WorkOrderType,
        source_file: str
    ) -> List[WorkOrder]:
        """
        生成工单（按城市拆分）
        返回：工单列表
        """
        if not records:
            logger.warning("记录列表为空，无法生成工单")
            return []

        # 获取客户名称
        customer_name = records[0].customer_name if isinstance(records[0], (AdditionRecord, ReductionRecord)) else "未知客户"

        # 按城市分组
        city_groups = self._group_by_city(records, workorder_type)

        # 为每个城市生成工单
        workorders = []
        for city, city_records in city_groups.items():
            workorder_id = self._generate_workorder_id()

            # 转换记录为字典
            records_dict = []
            for record in city_records:
                if isinstance(record, AdditionRecord):
                    record_dict = record.to_dict()
                elif isinstance(record, ReductionRecord):
                    record_dict = record.to_dict()
                else:
                    logger.warning(f"未知记录类型: {type(record)}")
                    continue

                records_dict.append(record_dict)

            # 创建工单
            workorder = WorkOrder(
                workorder_id=workorder_id,
                workorder_type=workorder_type,
                customer_name=customer_name,
                city=city,
                records=records_dict,
                source_file=source_file
            )

            workorders.append(workorder)
            logger.info(f"生成工单: {workorder_id} ({city})，包含 {len(records_dict)} 条记录")

        return workorders

    def _group_by_city(self, records: List, workorder_type: WorkOrderType) -> Dict[str, List]:
        """按城市分组记录"""
        city_groups = {}

        for record in records:
            # 根据工单类型获取城市字段
            if isinstance(record, AdditionRecord):
                city = record.social_security_location.strip()
            elif isinstance(record, ReductionRecord):
                city = record.benefit_location.strip()
            else:
                city = self.default_city

            # 判断城市是否在预定义列表中
            if city not in self.cities and city != self.default_city:
                city = self.default_city

            # 分组
            if city not in city_groups:
                city_groups[city] = []

            city_groups[city].append(record)

        return city_groups

    def _generate_workorder_id(self) -> str:
        """生成工单号"""
        # 格式: WO + YYYYMMDD + UUID前6位
        date_str = datetime.now().strftime("%Y%m%d")
        short_uuid = str(uuid.uuid4())[:6].upper()
        return f"WO{date_str}{short_uuid}"

    def save_workorder(self, workorder: WorkOrder) -> str:
        """
        保存工单到Excel文件
        返回：文件路径
        """
        # 命名格式：客户名称（城市类型）
        # 例如：上海誓炬医药科技有限公司（苏州派遣）
        work_type_name = "派遣" if workorder.workorder_type == WorkOrderType.ADDITION else "减员"
        city_display = workorder.city.split("-")[0] if "-" in workorder.city else workorder.city
        # 添加时间戳避免文件名冲突
        timestamp = datetime.now().strftime("%H%M%S")
        filename = f"{workorder.customer_name}（{city_display}{work_type_name}）_{timestamp}.xlsx"
        filepath = WORKORDER_DIR / filename

        # 创建DataFrame
        if workorder.records:
            # 将记录转换为DataFrame
            df = pd.DataFrame(workorder.records)

            # 添加工单元数据作为前几行
            metadata_rows = [
                ["工单号", workorder.workorder_id],
                ["工单类型", workorder.workorder_type.value],
                ["客户名称", workorder.customer_name],
                ["城市", workorder.city],
                ["创建时间", workorder.created_at],
                ["状态", workorder.status],
                ["来源文件", workorder.source_file],
                ["总记录数", workorder.total_count],
                ["错误记录数", workorder.error_count],
                [],  # 空行分隔
            ]

            # 保存为Excel
            with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
                # 写入元数据
                metadata_df = pd.DataFrame(metadata_rows, columns=["字段", "值"])
                metadata_df.to_excel(writer, sheet_name='工单信息', index=False, header=False)

                # 写入记录数据
                df.to_excel(writer, sheet_name='记录明细', index=False)

        logger.info(f"工单已保存: {filepath}")
        return str(filepath)

    def save_workorders(self, workorders: List[WorkOrder]) -> List[str]:
        """
        批量保存工单
        返回：文件路径列表
        """
        filepaths = []
        for workorder in workorders:
            filepath = self.save_workorder(workorder)
            filepaths.append(filepath)

        return filepaths

    def generate_summary(self, workorders: List[WorkOrder]) -> Dict:
        """生成工单汇总信息"""
        summary = {
            "工单总数": len(workorders),
            "总记录数": sum(w.total_count for w in workorders),
            "错误记录数": sum(w.error_count for w in workorders),
            "城市分布": {},
            "客户列表": list(set(w.customer_name for w in workorders)),
            "生成时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # 统计城市分布
        for workorder in workorders:
            city = workorder.city
            if city not in summary["城市分布"]:
                summary["城市分布"][city] = 0
            summary["城市分布"][city] += 1

        # 生成汇总Excel文件
        self._save_summary_to_excel(summary)

        return summary

    def _save_summary_to_excel(self, summary: Dict):
        """保存汇总信息到Excel"""
        summary_filename = f"工单汇总_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        summary_filepath = WORKORDER_DIR / summary_filename

        with pd.ExcelWriter(summary_filepath, engine='openpyxl') as writer:
            # 工单汇总
            summary_df = pd.DataFrame([
                ["工单总数", summary["工单总数"]],
                ["总记录数", summary["总记录数"]],
                ["错误记录数", summary["错误记录数"]],
                ["生成时间", summary["生成时间"]]
            ], columns=["统计项", "值"])
            summary_df.to_excel(writer, sheet_name='汇总统计', index=False)

            # 城市分布
            city_df = pd.DataFrame(
                list(summary["城市分布"].items()),
                columns=["城市", "工单数量"]
            )
            city_df.to_excel(writer, sheet_name='城市分布', index=False)

            # 客户列表
            customer_df = pd.DataFrame(
                {"客户名称": summary["客户列表"]}
            )
            customer_df.to_excel(writer, sheet_name='客户列表', index=False)

        logger.info(f"工单汇总已保存: {summary_filepath}")
