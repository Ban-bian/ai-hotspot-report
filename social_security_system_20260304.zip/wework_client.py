"""
企业微信客户端模块 - 接收消息和发送工单
"""
import requests
import json
import hashlib
import base64
import time
from typing import Dict, List, Optional, Any
import logging
from pathlib import Path
from datetime import datetime

from config.settings import WEWORK_CONFIG, WORKORDER_DIR

logger = logging.getLogger(__name__)


class WeWorkClient:
    """企业微信应用客户端"""

    def __init__(self, config: Optional[Dict] = None):
        """初始化企业微信客户端

        Args:
            config: 企业微信配置，默认使用WEWORK_CONFIG
        """
        self.config = config or WEWORK_CONFIG
        self.corp_id = self.config.get("corp_id", "")
        self.agent_id = self.config.get("agent_id", "")
        self.secret = self.config.get("secret", "")
        self.token = self.config.get("token", "")
        self.encoding_aes_key = self.config.get("encoding_aes_key", "")

        self.access_token = None
        self.token_expires_at = 0

        self.api_base = "https://qyapi.weixin.qq.com/cgi-bin"

    def get_access_token(self) -> Optional[str]:
        """获取Access Token

        Returns:
            Access Token，失败返回None
        """
        # 如果token未过期，直接返回
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token

        try:
            url = f"{self.api_base}/gettoken"
            params = {
                "corpid": self.corp_id,
                "corpsecret": self.secret
            }

            response = requests.get(url, params=params, timeout=10)
            data = response.json()

            if data.get("errcode") == 0:
                self.access_token = data["access_token"]
                # 提前5分钟过期
                self.token_expires_at = time.time() + data["expires_in"] - 300
                logger.info("成功获取企业微信Access Token")
                return self.access_token
            else:
                logger.error(f"获取Access Token失败: {data}")
                return None

        except Exception as e:
            logger.error(f"获取Access Token异常: {e}")
            return None

    def send_text_message(self, user_id: str, content: str) -> Dict:
        """发送文本消息

        Args:
            user_id: 用户ID（@all表示全员）
            content: 消息内容

        Returns:
            响应结果
        """
        access_token = self.get_access_token()
        if not access_token:
            return {"errcode": -1, "errmsg": "未获取到Access Token"}

        try:
            url = f"{self.api_base}/message/send?access_token={access_token}"
            data = {
                "touser": user_id,
                "msgtype": "text",
                "agentid": self.agent_id,
                "text": {
                    "content": content
                },
                "safe": 0
            }

            response = requests.post(url, json=data, timeout=10)
            result = response.json()

            if result.get("errcode") == 0:
                logger.info(f"成功发送文本消息给 {user_id}")
            else:
                logger.error(f"发送文本消息失败: {result}")

            return result

        except Exception as e:
            logger.error(f"发送文本消息异常: {e}")
            return {"errcode": -1, "errmsg": str(e)}

    def send_file_message(self, user_id: str, media_id: str) -> Dict:
        """发送文件消息

        Args:
            user_id: 用户ID
            media_id: 媒体文件ID

        Returns:
            响应结果
        """
        access_token = self.get_access_token()
        if not access_token:
            return {"errcode": -1, "errmsg": "未获取到Access Token"}

        try:
            url = f"{self.api_base}/message/send?access_token={access_token}"
            data = {
                "touser": user_id,
                "msgtype": "file",
                "agentid": self.agent_id,
                "file": {
                    "media_id": media_id
                },
                "safe": 0
            }

            response = requests.post(url, json=data, timeout=10)
            result = response.json()

            if result.get("errcode") == 0:
                logger.info(f"成功发送文件消息给 {user_id}")
            else:
                logger.error(f"发送文件消息失败: {result}")

            return result

        except Exception as e:
            logger.error(f"发送文件消息异常: {e}")
            return {"errcode": -1, "errmsg": str(e)}

    def upload_temporary_media(self, file_path: str, media_type: str = "file") -> Optional[str]:
        """上传临时素材

        Args:
            file_path: 文件路径
            media_type: 媒体类型 (image, voice, video, file)

        Returns:
            media_id，失败返回None
        """
        access_token = self.get_access_token()
        if not access_token:
            return None

        try:
            url = f"{self.api_base}/media/upload?access_token={access_token}&type={media_type}"

            with open(file_path, 'rb') as f:
                files = {
                    'media': (Path(file_path).name, f, 'application/octet-stream')
                }
                response = requests.post(url, files=files, timeout=30)

            data = response.json()

            if data.get("errcode") == 0:
                media_id = data["media_id"]
                logger.info(f"成功上传临时素材: {Path(file_path).name} (media_id: {media_id})")
                return media_id
            else:
                logger.error(f"上传临时素材失败: {data}")
                return None

        except Exception as e:
            logger.error(f"上传临时素材异常: {e}")
            return None

    def send_workorder_to_operator(self, file_path: str, operator_userids: List[str],
                                    city: str, customer_name: str) -> bool:
        """发送工单给实操客服

        Args:
            file_path: 工单文件路径
            operator_userids: 实操客服用户ID列表
            city: 城市
            customer_name: 客户名称

        Returns:
            发送成功返回True
        """
        if not operator_userids:
            logger.warning("未指定实操客服人员")
            return False

        try:
            # 上传工单文件
            media_id = self.upload_temporary_media(file_path)
            if not media_id:
                logger.error("上传工单文件失败")
                return False

            # 发送给每个实操客服
            success_count = 0
            for user_id in operator_userids:
                # 构建消息
                content = f"""【社保工单】来自前道客服Agent

客户名称: {customer_name}
城市: {city}
工单文件: {Path(file_path).name}
生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

请及时处理此工单。"""

                # 发送文本消息
                text_result = self.send_text_message(user_id, content)

                # 发送文件
                file_result = self.send_file_message(user_id, media_id)

                if text_result.get("errcode") == 0 and file_result.get("errcode") == 0:
                    success_count += 1
                    logger.info(f"工单已成功发送给 {user_id}")

            # 统计结果
            if success_count == len(operator_userids):
                logger.info(f"工单已成功发送给所有实操客服 ({success_count}/{len(operator_userids)})")
                return True
            else:
                logger.warning(f"工单发送完成，部分失败 ({success_count}/{len(operator_userids)})")
                return success_count > 0

        except Exception as e:
            logger.error(f"发送工单异常: {e}")
            return False

    def get_user_info(self, user_id: str) -> Optional[Dict]:
        """获取用户信息

        Args:
            user_id: 用户ID

        Returns:
            用户信息字典
        """
        access_token = self.get_access_token()
        if not access_token:
            return None

        try:
            url = f"{self.api_base}/user/get?access_token={access_token}&userid={user_id}"
            response = requests.get(url, timeout=10)
            data = response.json()

            if data.get("errcode") == 0:
                return data
            else:
                logger.error(f"获取用户信息失败: {data}")
                return None

        except Exception as e:
            logger.error(f"获取用户信息异常: {e}")
            return None

    def get_department_users(self, department_id: int) -> List[Dict]:
        """获取部门成员列表

        Args:
            department_id: 部门ID

        Returns:
            用户列表
        """
        access_token = self.get_access_token()
        if not access_token:
            return []

        try:
            url = f"{self.api_base}/user/list?access_token={access_token}&department_id={department_id}"
            response = requests.get(url, timeout=10)
            data = response.json()

            if data.get("errcode") == 0:
                return data.get("userlist", [])
            else:
                logger.error(f"获取部门成员失败: {data}")
                return []

        except Exception as e:
            logger.error(f"获取部门成员异常: {e}")
            return []


# 城市实操客服映射表（示例配置）
CITY_OPERATOR_MAP = {
    "北京": ["zhangsan", "lisi"],
    "上海": ["wangwu"],
    "广州": ["zhaoliu"],
    "深圳": ["sunqi"],
    "杭州": ["zhouba"],
    "成都": ["wujiu"],
    "武汉": ["zhengshi"],
    "西安": ["chenshier"],
    "南京": ["lvdashisan"],
    "苏州": ["zhousi"],
    "其他城市": ["default_operator"]
}


def get_city_operators(city: str) -> List[str]:
    """获取指定城市的实操客服人员ID

    Args:
        city: 城市名称

    Returns:
        用户ID列表
    """
    return CITY_OPERATOR_MAP.get(city, CITY_OPERATOR_MAP.get("其他城市", []))


def test_wework_connection(config: Dict) -> bool:
    """测试企业微信连接

    Args:
        config: 企业微信配置

    Returns:
        连接成功返回True
    """
    try:
        client = WeWorkClient(config)
        token = client.get_access_token()
        return token is not None
    except Exception as e:
        logger.error(f"企业微信连接测试失败: {e}")
        return False
