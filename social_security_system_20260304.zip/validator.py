"""
字段校验模块
用于校验社保增减员工单的字段正确性
"""
import re
from typing import List, Dict, Tuple
from datetime import datetime
import logging

from config.settings import (
    VALIDATION_RULES, SOCIAL_SECURITY_BASE, DATE_FORMATS,
    ADDITION_REQUIRED_FIELDS, REDUCTION_REQUIRED_FIELDS
)
from models.schema import AdditionRecord, ReductionRecord

logger = logging.getLogger(__name__)


class FieldValidator:
    """字段验证器"""

    def __init__(self):
        self.validation_rules = VALIDATION_RULES

    def validate_addition_record(self, record: AdditionRecord) -> Tuple[bool, List[str]]:
        """
        验证增员记录
        返回：(是否通过, 错误列表)
        """
        errors = []

        # 转换为字典以便验证
        record_dict = {
            "客户派单日期": record.customer_order_date,
            "客户名称": record.customer_name,
            "人员分类": record.person_category,
            "身份证号": record.id_card,
            "姓名": record.name,
            "联系电话": record.phone,
            "社保缴纳地": record.social_security_location,
            "实际工作地": record.work_location,
            "户口性质": record.household_type,
            "社保类别": record.social_security_type,
            "社保基数": record.social_security_base,
            "社保起缴年月": record.social_security_start_month,
            "公积金基数": record.housing_fund_base,
            "公积金比例": record.housing_fund_rate,
            "起缴年月": record.housing_fund_start_month,
            "个人公积金账号": record.personal_housing_fund_account
        }

        # 验证各字段
        for field, value in record_dict.items():
            field_errors = self._validate_field(field, value, record.row_index)
            errors.extend(field_errors)

        # 额外验证
        errors.extend(self._validate_social_security_base(record.social_security_base, record.row_index))
        errors.extend(self._validate_housing_fund_base(record.housing_fund_base, record.row_index))
        errors.extend(self._validate_month_format(record.social_security_start_month, "社保起缴年月", record.row_index))
        errors.extend(self._validate_month_format(record.housing_fund_start_month, "起缴年月", record.row_index))

        # 更新记录的错误列表
        record.validation_errors = errors

        return len(errors) == 0, errors

    def validate_reduction_record(self, record: ReductionRecord) -> Tuple[bool, List[str]]:
        """
        验证减员记录
        返回：(是否通过, 错误列表)
        """
        errors = []

        # 转换为字典
        record_dict = {
            "客户派单日期": record.customer_order_date,
            "客户名称": record.customer_name,
            "人员分类": record.person_category,
            "身份证号": record.id_card,
            "姓名": record.name,
            "联系电话": record.phone,
            "福利缴纳地": record.benefit_location,
            "离职日期": record.resignation_date,
            "社保类别": record.social_security_type,
            "社保不产生月": record.social_security_non_production_month,
            "公积金不产生月": record.housing_fund_non_production_month,
            "停缴原因": record.stop_reason
        }

        # 验证各字段
        for field, value in record_dict.items():
            field_errors = self._validate_field(field, value, record.row_index)
            errors.extend(field_errors)

        # 额外验证
        errors.extend(self._validate_month_format(record.social_security_non_production_month, "社保不产生月", record.row_index))
        errors.extend(self._validate_month_format(record.housing_fund_non_production_month, "公积金不产生月", record.row_index))

        # 更新记录的错误列表
        record.validation_errors = errors

        return len(errors) == 0, errors

    def _validate_field(self, field_name: str, value: any, row_index: int) -> List[str]:
        """验证单个字段"""
        errors = []

        if field_name not in self.validation_rules:
            return errors

        rule = self.validation_rules[field_name]
        str_value = str(value).strip()

        # 检查必填
        if rule.get("required", False) and not str_value:
            errors.append(f"第{row_index}行：【{field_name}】为必填项，不能为空")
            return errors

        # 如果为空且非必填，跳过其他验证
        if not str_value:
            return errors

        # 检查最小长度
        if "min_length" in rule and len(str_value) < rule["min_length"]:
            errors.append(f"第{row_index}行：【{field_name}】长度不足，至少需要 {rule['min_length']} 个字符")

        # 检查选项
        if "options" in rule and str_value not in rule["options"]:
            errors.append(f"第{row_index}行：【{field_name}】值 '{str_value}' 不在允许选项中: {', '.join(rule['options'])}")

        # 检查正则模式
        if "pattern" in rule:
            pattern = rule["pattern"]
            if not re.match(pattern, str_value):
                errors.append(f"第{row_index}行：【{field_name}】格式不正确，'{str_value}' 不符合规范")

        return errors

    def _validate_social_security_base(self, value: float, row_index: int) -> List[str]:
        """验证社保基数"""
        errors = []

        if value == 0:
            errors.append(f"第{row_index}行：【社保基数】不能为0")
        elif value < SOCIAL_SECURITY_BASE["min"]:
            errors.append(f"第{row_index}行：【社保基数】低于最低标准 {SOCIAL_SECURITY_BASE['min']}")
        elif value > SOCIAL_SECURITY_BASE["max"]:
            errors.append(f"第{row_index}行：【社保基数】超过最高标准 {SOCIAL_SECURITY_BASE['max']}")

        return errors

    def _validate_housing_fund_base(self, value: float, row_index: int) -> List[str]:
        """验证公积金基数"""
        errors = []

        if value == 0:
            errors.append(f"第{row_index}行：【公积金基数】不能为0")

        return errors

    def _validate_month_format(self, value: str, field_name: str, row_index: int) -> List[str]:
        """验证月份格式 (YYYY-MM)"""
        errors = []

        if not value.strip():
            return errors

        # 检查格式
        if not re.match(r"^\d{4}-\d{2}$", value):
            errors.append(f"第{row_index}行：【{field_name}】格式不正确，应为 YYYY-MM（如：2024-01）")
            return errors

        # 检查是否为有效月份
        try:
            year, month = map(int, value.split("-"))
            if not (1 <= month <= 12):
                errors.append(f"第{row_index}行：【{field_name}】月份无效，应在 01-12 之间")
            if year < 2000 or year > 2100:
                errors.append(f"第{row_index}行：【{field_name}】年份无效")
        except ValueError:
            errors.append(f"第{row_index}行：【{field_name}】格式不正确")

        return errors

    def validate_batch(self, records: List, record_type: str) -> Dict:
        """
        批量验证记录
        返回：验证结果统计
        """
        total = len(records)
        valid_count = 0
        error_count = 0
        all_errors = []

        for record in records:
            if record_type == "addition":
                is_valid, errors = self.validate_addition_record(record)
            else:
                is_valid, errors = self.validate_reduction_record(record)

            if is_valid:
                valid_count += 1
            else:
                error_count += 1
                all_errors.extend(errors)

        return {
            "总记录数": total,
            "通过验证": valid_count,
            "验证失败": error_count,
            "错误详情": all_errors
        }
