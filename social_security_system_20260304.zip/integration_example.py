"""
使用示例：邮件和企业微信集成
"""
import logging
from modules.email_client import EmailClient, test_email_connection
from modules.wework_client import WeWorkClient, test_wework_connection, CITY_OPERATOR_MAP
from modules.wework_message import WeWorkMessageParser, WeWorkMessage
from modules.integration import SocialSecurityIntegration

logging.basicConfig(level=logging.INFO)


def example_1_read_emails():
    """示例1：读取邮件中的Excel附件"""
    print("\n" + "=" * 60)
    print("示例1：读取邮件中的Excel附件")
    print("=" * 60)

    # 配置邮件信息（请替换为实际配置）
    email_config = {
        "enabled": True,
        "imap_server": "imap.qq.com",  # QQ邮箱
        "imap_port": 993,
        "smtp_username": "your_email@qq.com",
        "smtp_password": "your_imap_password",  # 注意：这是IMAP授权码，不是邮箱密码
        "inbox_folder": "INBOX",
        "attachment_download_dir": "./data/attachments"
    }

    # 测试连接
    if test_email_connection(email_config):
        print("✓ 邮件服务器连接成功")
    else:
        print("✗ 邮件服务器连接失败")
        return

    # 读取未读邮件
    with EmailClient(email_config) as client:
        emails = client.fetch_unread_emails()

        for email in emails:
            print(f"\n邮件主题: {email['subject']}")
            print(f"发件人: {email['sender']}")

            # 下载Excel附件
            excel_files = client.download_excel_attachments(email)
            if excel_files:
                print(f"Excel附件: {excel_files}")

            # 标记为已读
            client.mark_as_read(email['id'])


def example_2_send_wework_message():
    """示例2：通过企业微信发送工单给实操客服"""
    print("\n" + "=" * 60)
    print("示例2：通过企业微信发送工单给实操客服")
    print("=" * 60)

    # 配置企业微信信息（请替换为实际配置）
    wework_config = {
        "enabled": True,
        "corp_id": "wwxxxxxxxxxxxxx",  # 企业ID
        "agent_id": "1000001",  # 应用ID
        "secret": "xxxxxxxxxxxxxxxxxxxx",  # 应用Secret
        "token": "your_token",
        "encoding_aes_key": "your_encoding_aes_key"
    }

    # 测试连接
    if test_wework_connection(wework_config):
        print("✓ 企业微信连接成功")
    else:
        print("✗ 企业微信连接失败")
        return

    # 创建客户端
    client = WeWorkClient(wework_config)

    # 发送文本消息
    result = client.send_text_message("zhangsan", "这是一条测试消息")
    print(f"发送结果: {result}")

    # 发送工单文件给实操客服
    workorder_file = "./output/workorders/test_workorder.xlsx"
    operators = CITY_OPERATOR_MAP.get("北京", [])

    if operators:
        success = client.send_workorder_to_operator(
            file_path=workorder_file,
            operator_userids=operators,
            city="北京",
            customer_name="测试客户"
        )
        print(f"工单发送结果: {'成功' if success else '失败'}")


def example_3_integration():
    """示例3：运行完整整合流程"""
    print("\n" + "=" * 60)
    print("示例3：运行完整整合流程")
    print("=" * 60)

    # 创建整合Agent
    integration = SocialSecurityIntegration()

    # 处理单个Excel文件（模拟从邮件或企业微信接收到的文件）
    excel_file = "./examples/addition_example.xlsx"

    # 处理Excel文件
    success = integration.process_email_excel(excel_file)

    if success:
        print("✓ Excel文件处理成功")
    else:
        print("✗ Excel文件处理失败")


def example_4_wework_message_parser():
    """示例4：解析企业微信消息"""
    print("\n" + "=" * 60)
    print("示例4：解析企业微信消息")
    print("=" * 60)

    # 创建消息解析器
    parser = WeWorkMessageParser(
        token="your_token",
        encoding_aes_key="your_encoding_aes_key"
    )

    # 示例：解析文本消息
    text_message_xml = """
    <xml>
        <ToUserName><![CDATA[agent]]></ToUserName>
        <FromUserName><![CDATA[zhangsan]]></FromUserName>
        <CreateTime>1234567890</CreateTime>
        <MsgType><![CDATA[text]]></MsgType>
        <Content><![CDATA[你好]]></Content>
        <MsgId>1234567890123456</MsgId>
    </xml>
    """

    message = parser.parse_message(text_message_xml)
    if message:
        print(f"消息类型: {message.msg_type}")
        print(f"发送者: {message.from_user}")
        print(f"内容: {message.content}")

    # 示例：解析文件消息
    file_message_xml = """
    <xml>
        <ToUserName><![CDATA[agent]]></ToUserName>
        <FromUserName><![CDATA[zhangsan]]></FromUserName>
        <CreateTime>1234567890</CreateTime>
        <MsgType><![CDATA[file]]></MsgType>
        <FileTitle><![CDATA[增员表.xlsx]]></FileTitle>
        <FileExt><![CDATA[xlsx]]></FileExt>
        <MediaId><![CDATA[media_id_123]]></MediaId>
        <MsgId>1234567890123456</MsgId>
    </xml>
    """

    message = parser.parse_message(file_message_xml)
    if message:
        print(f"消息类型: {message.msg_type}")
        print(f"发送者: {message.from_user}")
        print(f"文件名: {message.content.get('file_title')}")
        print(f"是否为Excel: {parser.is_excel_file(message)}")


def example_5_city_operator_mapping():
    """示例5：城市实操客服映射"""
    print("\n" + "=" * 60)
    print("示例5：城市实操客服映射")
    print("=" * 60)

    # 查看当前城市映射配置
    print("城市实操客服映射表:")
    for city, operators in CITY_OPERATOR_MAP.items():
        print(f"  {city}: {', '.join(operators)}")

    # 添加新城市
    CITY_OPERATOR_MAP["天津"] = ["user_a", "user_b"]
    print("\n添加天津城市映射成功")

    # 查询指定城市的实操客服
    city = "北京"
    from modules.wework_client import get_city_operators
    operators = get_city_operators(city)
    print(f"\n城市 {city} 的实操客服: {operators}")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("邮件和企业微信集成示例")
    print("=" * 60)

    # 运行各个示例
    # example_1_read_emails()
    # example_2_send_wework_message()
    # example_3_integration()
    # example_4_wework_message_parser()
    example_5_city_operator_mapping()

    print("\n" + "=" * 60)
    print("示例运行完成")
    print("=" * 60)
