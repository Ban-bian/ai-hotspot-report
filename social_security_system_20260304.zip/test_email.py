"""
一次性邮件处理测试
"""
import logging
from pathlib import Path

from config.settings import LOG_DIR, LOG_FILE, EMAIL_CONFIG
from modules.email_client import EmailClient
from modules.integration import SocialSecurityIntegration

# 配置日志
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def test_email_processing():
    """测试邮件处理"""
    logger.info("=" * 60)
    logger.info("开始邮件处理测试")
    logger.info("=" * 60)

    # 创建整合Agent
    integration = SocialSecurityIntegration()

    # 连接邮件服务器
    logger.info("\n步骤1: 连接邮件服务器...")
    if not integration.email_client.connect():
        logger.error("无法连接邮件服务器")
        return

    # 获取未读邮件
    logger.info("\n步骤2: 获取未读邮件...")
    unread_emails = integration.email_client.fetch_unread_emails()
    logger.info(f"找到 {len(unread_emails)} 封未读邮件")

    if not unread_emails:
        logger.info("邮箱中没有未读邮件")
        logger.info("\n提示: 请发送一封带Excel附件的邮件到 48326583@qq.com 进行测试")
        integration.email_client.disconnect()
        return

    # 处理每封邮件
    logger.info("\n步骤3: 处理邮件...")
    processed_count = 0

    for email_data in unread_emails:
        try:
            logger.info(f"\n处理邮件: {email_data['subject']}")
            logger.info(f"  发件人: {email_data['sender']}")
            logger.info(f"  日期: {email_data['date']}")

            # 提取Excel附件
            excel_files = integration.email_client.download_excel_attachments(email_data)

            if not excel_files:
                logger.warning(f"  警告: 邮件无Excel附件")
                integration.email_client.mark_as_read(email_data['id'])
                continue

            logger.info(f"  Excel附件: {len(excel_files)} 个")

            # 处理每个Excel文件
            for excel_path in excel_files:
                logger.info(f"\n  处理文件: {Path(excel_path).name}")
                if integration.process_email_excel(excel_path):
                    processed_count += 1
                    logger.info(f"  ✓ 处理成功")
                else:
                    logger.error(f"  ✗ 处理失败")

            # 标记为已读
            integration.email_client.mark_as_read(email_data['id'])
            logger.info(f"  ✓ 邮件已标记为已读")

        except Exception as e:
            logger.error(f"  处理邮件失败: {e}")

    # 断开连接
    integration.email_client.disconnect()

    # 输出结果
    logger.info("\n" + "=" * 60)
    logger.info("测试完成")
    logger.info(f"总共处理: {processed_count} 个Excel文件")
    logger.info("=" * 60)


if __name__ == "__main__":
    test_email_processing()
