"""
数据模型定义
"""
from dataclasses import dataclass, field
from typing import List, Optional, Literal
from datetime import datetime
from enum import Enum


class WorkOrderType(Enum):
    """工单类型"""
    ADDITION = "增员"  # 社保增员
    REDUCTION = "减员"  # 社保减员


class PersonCategory(Enum):
    """人员分类"""
    OUTSOURCE = "外包"
    DISPATCH = "派遣"
    AGENCY = "代理"


class HouseholdType(Enum):
    """户口性质"""
    URBAN = "城镇"
    RURAL = "农村"


class SocialSecurityType(Enum):
    """社保类别"""
    FIVE = "五险"
    PENSION_MEDICAL = "养老+医疗"
    PENSION = "养老"
    MEDICAL = "医疗"
    HOUSING_FUND = "住房公积金"


@dataclass
class AdditionRecord:
    """增员记录"""
    # 基础信息
    customer_order_date: str  # 客户派单日期
    customer_name: str  # 客户名称
    person_category: str  # 人员分类（外包/派遣/代理）
    id_card: str  # 身份证号
    name: str  # 姓名
    phone: str  # 联系电话

    # 社保信息
    social_security_location: str  # 社保缴纳地
    work_location: str  # 实际工作地
    household_type: str  # 户口性质
    social_security_type: str  # 社保类别
    social_security_base: float  # 社保基数
    social_security_start_month: str  # 社保起缴年月（YYYY-MM）

    # 公积金信息
    housing_fund_base: float  # 公积金基数
    housing_fund_rate: float  # 公积金比例
    housing_fund_start_month: str  # 起缴年月（YYYY-MM）
    personal_housing_fund_account: str  # 个人公积金账号

    # 元数据
    row_index: int = -1  # 在Excel中的行号
    validation_errors: List[str] = field(default_factory=list)  # 验证错误列表

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "客户派单日期": self.customer_order_date,
            "客户名称": self.customer_name,
            "人员分类": self.person_category,
            "身份证号": self.id_card,
            "姓名": self.name,
            "联系电话": self.phone,
            "社保缴纳地": self.social_security_location,
            "实际工作地": self.work_location,
            "户口性质": self.household_type,
            "社保类别": self.social_security_type,
            "社保基数": self.social_security_base,
            "社保起缴年月": self.social_security_start_month,
            "公积金基数": self.housing_fund_base,
            "公积金比例": self.housing_fund_rate,
            "起缴年月": self.housing_fund_start_month,
            "个人公积金账号": self.personal_housing_fund_account,
            "行号": self.row_index
        }


@dataclass
class ReductionRecord:
    """减员记录"""
    # 基础信息
    customer_order_date: str  # 客户派单日期
    customer_name: str  # 客户名称
    person_category: str  # 人员分类（外包/派遣/代理）
    id_card: str  # 身份证号
    name: str  # 姓名
    phone: str  # 联系电话

    # 福利信息
    benefit_location: str  # 福利缴纳地
    resignation_date: str  # 离职日期
    social_security_type: str  # 社保类别
    social_security_non_production_month: str  # 社保不产生月（YYYY-MM）
    housing_fund_non_production_month: str  # 公积金不产生月（YYYY-MM）
    stop_reason: str  # 停缴原因

    # 元数据
    row_index: int = -1  # 在Excel中的行号
    validation_errors: List[str] = field(default_factory=list)  # 验证错误列表

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "客户派单日期": self.customer_order_date,
            "客户名称": self.customer_name,
            "人员分类": self.person_category,
            "身份证号": self.id_card,
            "姓名": self.name,
            "联系电话": self.phone,
            "福利缴纳地": self.benefit_location,
            "离职日期": self.resignation_date,
            "社保类别": self.social_security_type,
            "社保不产生月": self.social_security_non_production_month,
            "公积金不产生月": self.housing_fund_non_production_month,
            "停缴原因": self.stop_reason,
            "行号": self.row_index
        }


@dataclass
class WorkOrder:
    """工单"""
    workorder_id: str  # 工单号
    workorder_type: WorkOrderType  # 工单类型（增员/减员）
    customer_name: str  # 客户名称
    city: str  # 城市
    records: List[dict]  # 记录列表

    # 元数据
    created_at: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    status: str = "待处理"  # 状态：待处理/处理中/已完成/已关闭
    source_file: str = ""  # 来源文件名
    total_count: int = 0  # 总记录数
    error_count: int = 0  # 错误记录数

    def __post_init__(self):
        """初始化后处理"""
        self.total_count = len(self.records)
        self.error_count = len([r for r in self.records if r.get("validation_errors")])

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "工单号": self.workorder_id,
            "工单类型": self.workorder_type.value,
            "客户名称": self.customer_name,
            "城市": self.city,
            "创建时间": self.created_at,
            "状态": self.status,
            "来源文件": self.source_file,
            "总记录数": self.total_count,
            "错误记录数": self.error_count,
            "记录": self.records
        }


@dataclass
class CustomerErrorRecord:
    """客户错误记录"""
    customer_name: str  # 客户名称
    error_count: int  # 错误次数
    last_error_date: str  # 最后错误日期
    last_error_reason: str  # 最后错误原因
    escalate_to_manual: bool = False  # 是否已转人工客服

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "客户名称": self.customer_name,
            "错误次数": self.error_count,
            "最后错误日期": self.last_error_date,
            "最后错误原因": self.last_error_reason,
            "已转人工": self.escalate_to_manual
        }


@dataclass
class CommunicationRecord:
    """沟通记录"""
    record_id: str  # 记录ID
    customer_name: str  # 客户名称
    communication_type: Literal["邮件", "企业微信"]  # 沟通类型
    direction: Literal["发送", "接收"]  # 方向
    content: str  # 内容
    timestamp: str  # 时间戳
    status: str = "成功"  # 状态

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "记录ID": self.record_id,
            "客户名称": self.customer_name,
            "沟通类型": self.communication_type,
            "方向": self.direction,
            "内容": self.content,
            "时间戳": self.timestamp,
            "状态": self.status
        }
